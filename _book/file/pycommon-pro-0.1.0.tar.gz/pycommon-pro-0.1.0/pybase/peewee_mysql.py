# -*- coding: utf-8 -*-
from peewee import *
from scrapy.utils.project import get_project_settings
import logging
setting = get_project_settings()
databases = MySQLDatabase(setting.get('MYSQL_DATABASE'),
                         user=setting.get('MYSQL_USER'),
                         passwd=str(setting.get('MYSQL_PASSWORD')),
                         host=setting.get('MYSQL_HOST'),
                         port=setting.get('MYSQL_PORT'))


class Peewee(Model):
    menu_id = CharField(unique=True)
    name = CharField()
    parent_menu_id = CharField()
    seq = IntegerField(default=0)
    path = CharField()

    class Meta:
        logging.getLogger(__name__).info(">>>>>>>>>>>>>>>>>>>>>>>>>  peewee table init.............................")

        table_name = setting.get('G_TABLE_NAME')
        database = databases


