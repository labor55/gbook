# -*- coding: utf-8 -*-
# @Time    : 2020/07/22
# @Author  : pengsiqi
# @Email   :
from scrapy.utils.apollo_client import ApolloClient
import threading
import warnings
import json
from scrapy.settings import Settings, BaseSettings
from scrapy.exceptions import NotExistWarning


def synchronized(func):
    func.__lock__ = threading.Lock()

    def lock_func(*args, **kwargs):
        with func.__lock__:
            return func(*args, **kwargs)

    return lock_func


def is_number(string):
    """
    判断一个字符串是否可转化为数字
    :param string:
    :return: True or False
    """
    str1 = str(string)
    if str1.isdigit():
        return True
    if str1.count('.') > 1:  # 判断小数点是不是大于1
        return False
    else:
        new_str = str1.split('.')  # 按小数点分割字符
        first_num = new_str[0]  # 取分割完之后这个list的第一个元素
        if first_num.count('-') > 1 or (
                first_num.count('-') == 1 and not first_num.startswith('-')):  # 判断负号的格数，如果大于1就是非法的
            return False
        else:
            first_num = first_num.replace('-', '')  # 把负号替换成空
    if (first_num.isdigit() and len(new_str) == 1) or (first_num.isdigit() and new_str[1].isdigit()):
        # 如果小数点两边都是整数的话，那么就是一个小数
        return True
    else:
        return False


def is_json(myjson):
    try:
        json.loads(myjson)
    except ValueError:
        return False
    return True


class ApolloSpiderConfigs:
    _instance = None
    _cache_config = {}
    _settings_key_list = Settings().attributes.keys()

    @synchronized
    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self, config):
        """
        get configuration from apollo
        """
        self._settings = config
        app_id_str = self._settings.get('APP_ID')
        if not app_id_str:
            return
        if app_id_str in self._cache_config.keys():
            apollo_item_list = self._cache_config.get(app_id_str)
            for item_dict in apollo_item_list:
                self._settings.set(item_dict.get_key(), item_dict.get_value())
        else:
            item_config_list = []
            app_ids = app_id_str.replace(' ', '').split(',')

            self.conf = {}
            for app_id in app_ids:
                client = None
                try:
                    client = ApolloClient(app_id=app_id,
                                          cluster=self._settings.get('CLUSTER'),
                                          config_server_url=self._settings.get('CONFIG_SERVER_URL'),
                                          timeout=5)
                    client.start(True, False, True)

                    for key in client.get_keys():
                        self.conf[key] = client.get_value(key)

                except Exception as e:
                    warnings.warn('apollo 连接超时。。。。请检查APP_ID: {}是否正确，或者网络问题。。'.format(app_id), NotExistWarning)
                finally:
                    if client is not None:
                        client.stop()
            for key, value in self.conf.items():
                value = str(value)
                # 判断是否能转化成数字
                if is_number(value):
                    if value.count('.') != 0:
                        value = float(value)
                    else:
                        value = int(value)

                # 判断是否可以转化成bool类型
                elif 'True' == value or 'False' == value:
                    value = bool(value)

                # 判断是否可以转化成json
                elif is_json(value):
                    value = json.loads(value)
                    if key in self._settings_key_list and isinstance(value, dict):
                        value = BaseSettings(value)

                self._settings.set(key, value)
                item_config_list.append(ConfigDict(key, value))

            self._cache_config[app_id_str] = item_config_list

    def get_settings(self):
        return self._settings

    def get_cache_config(self):
        return self.conf


class ConfigDict:
    key = None

    value = None

    def __init__(self, key, value):
        self.key = key
        self.value = value

    def get_key(self):
        return self.key

    def get_value(self):
        return self.value
