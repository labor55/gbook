# -*- coding: utf-8 -*-
from .peewee_mysql import Peewee
from scrapy.utils.project import get_project_settings


class MenuIdGenerator:

    settings = get_project_settings()

    def __init__(self):
        """
        初始化menu表，判断是否有初始菜单
        """

        if not Peewee.table_exists():
            Peewee.create_table()
            Peewee.create(menu_id=str(self.settings.get('G_ROOT_ID')),
                          name=self.settings.get('G_ROOT_NAME'),
                          parent_menu_id='0',
                          path=self.settings.get('G_ROOT_NAME'))

    def getMenuId(self, arr, parent_menu_id=str(settings.get('G_ROOT_ID'))):
        for name in arr:
            t = Peewee.select().where((Peewee.name == name) & (Peewee.parent_menu_id == parent_menu_id))
            if not t.exists():
                # 将menu_id为parent_menu_id的数据seq加一
                Peewee.update(seq=Peewee.seq + 1).where(Peewee.menu_id == parent_menu_id).execute()
                parent_node = Peewee.get(Peewee.menu_id == parent_menu_id)
                path = parent_node.path
                peq = str(parent_node.seq)
                pid = parent_node.menu_id
                new_id = (pid + peq) if len(peq) >= 3 else (pid + '0' + peq if len(peq) == 2 else pid + '00' + peq)
                new_path = path + '->' + name

                Peewee.insert(menu_id=new_id, name=name, parent_menu_id=pid, path=new_path).execute()

                parent_menu_id = new_id

            else:
                parent_menu_id = t.get().menu_id
        return parent_menu_id

